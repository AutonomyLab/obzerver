DBSCAN
======

Pretty fast DBSCAN C++ Boost OpenMP implementation
